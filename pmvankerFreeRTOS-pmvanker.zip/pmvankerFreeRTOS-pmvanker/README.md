hi Friends
This is Experimenting On FreeRTOS with Ubuntu

install for depedancy
sudo apt-get install libc6-dev-i386
